import { GoogleGenAI } from '@google/genai';
import { Zap, Upload, Download, RotateCcw, MessageSquare, TerminalSquare, Loader2, Expand, Shrink, Image as ImageIcon, X, AlignLeft, AlignCenter, AlignRight, Type, ArrowDownUp } from 'lucide-react';
import { useState, useEffect, useRef, useCallback } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Initialize Gemini dynamically in handleExecute

// IndexedDB for File System API handle
const GAI_CLOUD_DIR_KEY = 'GAI_CLOUD_DIR_HANDLE';
const GAI_IDB_NAME = 'GAI_CLOUD_IDB';
const GAI_IDB_STORE = 'handles';

function gaiOpenIDB() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open(GAI_IDB_NAME, 1);
    req.onupgradeneeded = (e: any) => e.target.result.createObjectStore(GAI_IDB_STORE);
    req.onsuccess = (e: any) => resolve(e.target.result);
    req.onerror = (e: any) => reject(e.target.error);
  });
}

async function gaiIdbPut(key: string, value: any) {
  const db = await gaiOpenIDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(GAI_IDB_STORE, 'readwrite');
    tx.objectStore(GAI_IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = (e: any) => reject(e.target.error);
  });
}

async function gaiIdbGet(key: string): Promise<FileSystemDirectoryHandle | null> {
  const db = await gaiOpenIDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAI_IDB_STORE, 'readonly');
    const req = tx.objectStore(GAI_IDB_STORE).get(key);
    req.onsuccess = (e: any) => resolve(e.target.result);
    req.onerror = (e: any) => reject(e.target.error);
  });
}

type Theme = 'DARK' | 'BLACK' | 'MID' | 'RED' | 'LIGHT' | 'PAPER';
type EngineType = 'BALANCED' | 'DEEP_RESEARCH' | 'QUICK';
type OutputFormat = 'STANDARD' | 'RAW_JSON' | 'MINIMAL';
type Provider = 'GEMINI' | 'GROQ';

interface HistoryItem {
  id: string;
  keyword: string;
  timestamp: string;
  result: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  image?: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState(() => localStorage.getItem('solid_studio_active_tab') || 'SEARCH_BUFFER');
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('solid_studio_theme') as Theme;
    if (saved === 'DARK' || saved === 'BLACK' || saved === 'MID' || saved === 'RED' || saved === 'LIGHT' || saved === 'PAPER') {
      return saved;
    }
    return 'DARK';
  });
  
  // Settings
  const [provider, setProvider] = useState<Provider>(() => (localStorage.getItem('solid_studio_provider') as Provider) || 'GEMINI');
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('solid_studio_api_key') || '');
  const [groqApiKey, setGroqApiKey] = useState(() => localStorage.getItem('solid_studio_groq_api_key') || localStorage.getItem('solid_studio_github_api_key') || '');
  const [engine, setEngine] = useState<EngineType>(() => (localStorage.getItem('solid_studio_engine') as EngineType) || 'BALANCED');
  const [density, setDensity] = useState(() => Number(localStorage.getItem('solid_studio_density') || '64'));
  const [outputFormat, setOutputFormat] = useState<OutputFormat>(() => (localStorage.getItem('solid_studio_output_format') as OutputFormat) || 'STANDARD');
  const [fontSizeRem, setFontSizeRem] = useState(() => Number(localStorage.getItem('solid_studio_font_size') || '0.85')); // Slider driven font size
  const [lineHeight, setLineHeight] = useState(() => Number(localStorage.getItem('solid_studio_line_height') || '1.6'));
  const [textAlign, setTextAlign] = useState<'left'|'center'|'right'>(() => (localStorage.getItem('solid_studio_text_align') as 'left'|'center'|'right') || 'left');
  const [paperMode, setPaperMode] = useState(() => localStorage.getItem('solid_studio_paper_mode') === 'true'); // Paper mode for text area
  const [isVertical, setIsVertical] = useState(() => localStorage.getItem('solid_studio_is_vertical') === 'true'); // Vertical writing mode
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => localStorage.getItem('solid_studio_is_sidebar_open') !== 'false');
  const [leftSidebarWidth, setLeftSidebarWidth] = useState<number>(() => {
    const saved = localStorage.getItem('solid_studio_left_sidebar_width');
    const parsed = saved ? parseInt(saved, 10) : 260;
    return !isNaN(parsed) && parsed >= 180 && parsed <= 600 ? parsed : 260;
  });
  const [rightSidebarWidth, setRightSidebarWidth] = useState<number>(() => {
    const saved = localStorage.getItem('solid_studio_right_sidebar_width');
    const parsed = saved ? parseInt(saved, 10) : 260;
    return !isNaN(parsed) && parsed >= 200 && parsed <= 600 ? parsed : 260;
  });
  const [isResizingLeft, setIsResizingLeft] = useState(false);
  const [isResizingRight, setIsResizingRight] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [language, setLanguage] = useState<'JP' | 'EN'>(() => (localStorage.getItem('solid_studio_language') as 'JP' | 'EN') || 'JP');

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const editScrollContainerRef = useRef<HTMLTextAreaElement | null>(null);
  const searchViewRef = useRef<HTMLDivElement | null>(null);

  // Maintain real-time reference to isVertical so listeners never miss updates
  const isVerticalRef = useRef(isVertical);
  useEffect(() => {
    isVerticalRef.current = isVertical;
    if (isVertical && searchViewRef.current) {
      searchViewRef.current.scrollTop = 0;
    }
  }, [isVertical]);

  const handleVerticalScroll = useCallback((container: HTMLElement, deltaY: number) => {
    if (deltaY === 0) return;
    const prev = container.scrollLeft;
    container.scrollBy({ left: -deltaY });
    if (container.scrollLeft === prev) {
      container.scrollLeft -= deltaY;
    }
  }, []);

  // Callback ref for SEARCH_BUFFER container - automatically binds whenever element mounts/remounts
  const setScrollContainerRef = useCallback((node: HTMLDivElement | null) => {
    scrollContainerRef.current = node;
    if (!node) return;

    const handleWheel = (e: WheelEvent) => {
      if (isVerticalRef.current && e.deltaY !== 0) {
        e.preventDefault();
        e.stopPropagation();
        handleVerticalScroll(node, e.deltaY);
      }
    };

    node.addEventListener('wheel', handleWheel, { passive: false });
  }, [handleVerticalScroll]);

  // Callback ref for EDIT_BUFFER textarea
  const setEditScrollContainerRef = useCallback((node: HTMLTextAreaElement | null) => {
    editScrollContainerRef.current = node;
    if (!node) return;

    const handleWheel = (e: WheelEvent) => {
      if (isVerticalRef.current && e.deltaY !== 0) {
        e.preventDefault();
        handleVerticalScroll(node, e.deltaY);
      }
    };

    node.addEventListener('wheel', handleWheel, { passive: false });
  }, [handleVerticalScroll]);

  // Delegated wheel listener on persistent search view wrapper
  useEffect(() => {
    const container = searchViewRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      if (isVerticalRef.current && e.deltaY !== 0) {
        const scroller = scrollContainerRef.current;
        if (scroller) {
          e.preventDefault();
          handleVerticalScroll(scroller, e.deltaY);
        }
      }
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [handleVerticalScroll]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(console.error);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(console.error);
      }
    }
  };

  // TTS State
  const [ttsVoices, setTtsVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [ttsVoiceURI, setTtsVoiceURI] = useState(() => localStorage.getItem('tts_voice_uri') || '');
  const [ttsRate, setTtsRate] = useState(() => Number(localStorage.getItem('tts_rate') || '1.0'));
  const [ttsPitch, setTtsPitch] = useState(() => Number(localStorage.getItem('tts_pitch') || '1.0'));
  const [ttsVolume, setTtsVolume] = useState(() => Number(localStorage.getItem('tts_volume') || '1.0'));
  const [ttsIsPlaying, setTtsIsPlaying] = useState(false);
  const ttsUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Search/Edit State
  const [prompt, setPrompt] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [output, setOutput] = useState(() => localStorage.getItem('solid_studio_output') || '');
  const [editContent, setEditContent] = useState('');
  
  // Attached Image
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // History & I/O
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('solid_studio_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load history', e);
    }
    return [];
  });
  const [copyStatus, setCopyStatus] = useState('結果をコピー (COPY)');
  const [importStatus, setImportStatus] = useState('インポート (IMPORT)');
  const importFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('solid_studio_theme', theme);
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      const THEME_HEADER_BG: Record<Theme, string> = {
        DARK: '#090b10',
        BLACK: '#050505',
        MID: '#1b1d25',
        RED: '#0d0404',
        LIGHT: '#e2e8f0',
        PAPER: '#EBE4D5'
      };
      metaThemeColor.setAttribute('content', THEME_HEADER_BG[theme] || '#090b10');
    }
  }, [theme]);

  // Load TTS voices (Filtered to: Ayumi, Haruka, Ichiro, Sayaka only)
  useEffect(() => {
    const loadVoices = () => {
      const allVoices = window.speechSynthesis.getVoices();
      if (allVoices.length > 0) {
        // 「あゆみ」「はるか」「一郎」「さやか」のみに厳格に限定
        const allowedKeywords = ['あゆみ', 'ayumi', 'はるか', 'haruka', '一郎', 'ichiro', 'さやか', 'sayaka'];
        const matchedVoices = allVoices.filter(v => 
          allowedKeywords.some(keyword => v.name.toLowerCase().includes(keyword.toLowerCase()))
        );

        // 該当音声があればその4種類のみをセット、万が一端末にない場合は日本語音声をフォールバック
        const voices = matchedVoices.length > 0 
          ? matchedVoices 
          : allVoices.filter(v => v.lang.startsWith('ja'));
        
        setTtsVoices(voices);

        // 選択中の音声が許可リストにない場合は先頭の有効な音声（あゆみ等）にリセット
        setTtsVoiceURI(prev => {
          if (prev && voices.some(v => v.voiceURI === prev)) return prev;
          return voices[0]?.voiceURI || '';
        });
      }
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => { window.speechSynthesis.cancel(); };
  }, []);

  // Window position & size memory with safe centering
  useEffect(() => {
    try {
      const savedX = localStorage.getItem("solid_studio_win_x");
      const savedY = localStorage.getItem("solid_studio_win_y");
      const savedW = localStorage.getItem("solid_studio_win_w");
      const savedH = localStorage.getItem("solid_studio_win_h");

      if (savedW && savedH && savedX !== null && savedY !== null) {
        const w = parseInt(savedW, 10);
        const h = parseInt(savedH, 10);
        const x = parseInt(savedX, 10);
        const y = parseInt(savedY, 10);

        if (w >= 600 && h >= 400) {
          window.resizeTo(w, h);
          const availLeft = (window.screen as any).availLeft || 0;
          const availTop = (window.screen as any).availTop || 0;
          const availW = window.screen.availWidth || 1920;
          const availH = window.screen.availHeight || 1080;

          if (x >= availLeft - 100 && x < availLeft + availW && y >= availTop - 100 && y < availTop + availH) {
            window.moveTo(x, y);
          }
        }
      } else {
        // First launch: center on screen
        const w = 1280, h = 850;
        const availLeft = (window.screen as any).availLeft || 0;
        const availTop = (window.screen as any).availTop || 0;
        const left = Math.max(availLeft, availLeft + Math.round((window.screen.availWidth - w) / 2));
        const top = Math.max(availTop, availTop + Math.round((window.screen.availHeight - h) / 2));
        window.resizeTo(w, h);
        window.moveTo(left, top);
      }
    } catch (e) {
      console.warn("Window positioning restricted by browser", e);
    }
  }, []);

  // Track window position and size on resize or before unload
  useEffect(() => {
    let debounceTimer: any;
    const saveMetrics = () => {
      try {
        const x = window.screenX !== undefined ? window.screenX : window.screenLeft;
        const y = window.screenY !== undefined ? window.screenY : window.screenTop;
        const w = window.outerWidth;
        const h = window.outerHeight;
        if (w >= 600 && h >= 400) {
          localStorage.setItem("solid_studio_win_x", String(x));
          localStorage.setItem("solid_studio_win_y", String(y));
          localStorage.setItem("solid_studio_win_w", String(w));
          localStorage.setItem("solid_studio_win_h", String(h));
        }
      } catch {}
    };

    const handleResize = () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(saveMetrics, 300);
    };

    window.addEventListener("resize", handleResize);
    window.addEventListener("beforeunload", saveMetrics);
    return () => {
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("beforeunload", saveMetrics);
      clearTimeout(debounceTimer);
    };
  }, []);

  // Stop TTS when output changes
  useEffect(() => {
    window.speechSynthesis.cancel();
    setTtsIsPlaying(false);
  }, [output]);

  const ttsSpeak = useCallback((text: string) => {
    if (!text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = ttsVoices.find(v => v.voiceURI === ttsVoiceURI);
    if (voice) utterance.voice = voice;
    utterance.rate = ttsRate;
    utterance.pitch = ttsPitch;
    utterance.volume = ttsVolume;
    utterance.onstart = () => setTtsIsPlaying(true);
    utterance.onend = () => setTtsIsPlaying(false);
    utterance.onerror = () => setTtsIsPlaying(false);
    ttsUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [ttsVoices, ttsVoiceURI, ttsRate, ttsPitch, ttsVolume]);

  const ttsStop = useCallback(() => {
    window.speechSynthesis.cancel();
    setTtsIsPlaying(false);
  }, []);

  const ttsPlayFromTop = useCallback(() => {
    if (!output) return;
    // Strip markdown symbols for cleaner reading
    const plain = output
      .replace(/#{1,6}\s+/g, '')
      .replace(/[\*_`~>\[\]]/g, '')
      .replace(/\|/g, ' ');
    ttsSpeak(plain);
  }, [output, ttsSpeak]);

  const ttsPlayFromParagraph = useCallback((paragraphText: string) => {
    if (!output || !paragraphText) return;
    // Find the position of clicked paragraph in full text, read from there
    const plain = output
      .replace(/#{1,6}\s+/g, '')
      .replace(/[\*_`~>\[\]]/g, '')
      .replace(/\|/g, ' ');
    const idx = plain.indexOf(paragraphText.substring(0, 30));
    const fromHere = idx > -1 ? plain.substring(idx) : plain;
    ttsSpeak(fromHere);
  }, [output, ttsSpeak]);

  // Persist history, API Key, and output
  useEffect(() => {
    localStorage.setItem('solid_studio_history', JSON.stringify(history));
  }, [history]);
  useEffect(() => {
    localStorage.setItem('solid_studio_api_key', apiKey);
  }, [apiKey]);
  useEffect(() => {
    localStorage.setItem('solid_studio_groq_api_key', groqApiKey);
  }, [groqApiKey]);
  useEffect(() => {
    localStorage.setItem('solid_studio_provider', provider);
  }, [provider]);
  useEffect(() => {
    localStorage.setItem('solid_studio_output', output);
  }, [output]);

  // Persist TTS settings
  useEffect(() => { localStorage.setItem('tts_rate', String(ttsRate)); }, [ttsRate]);
  useEffect(() => { localStorage.setItem('tts_pitch', String(ttsPitch)); }, [ttsPitch]);
  useEffect(() => { localStorage.setItem('tts_volume', String(ttsVolume)); }, [ttsVolume]);
  useEffect(() => { localStorage.setItem('tts_voice_uri', ttsVoiceURI); }, [ttsVoiceURI]);
  useEffect(() => { localStorage.setItem('solid_studio_theme', theme); }, [theme]);
  useEffect(() => { localStorage.setItem('solid_studio_active_tab', activeTab); }, [activeTab]);
  useEffect(() => { localStorage.setItem('solid_studio_engine', engine); }, [engine]);
  useEffect(() => { localStorage.setItem('solid_studio_density', String(density)); }, [density]);
  useEffect(() => { localStorage.setItem('solid_studio_output_format', outputFormat); }, [outputFormat]);
  useEffect(() => { localStorage.setItem('solid_studio_font_size', String(fontSizeRem)); }, [fontSizeRem]);
  useEffect(() => { localStorage.setItem('solid_studio_line_height', String(lineHeight)); }, [lineHeight]);
  useEffect(() => { localStorage.setItem('solid_studio_text_align', textAlign); }, [textAlign]);
  useEffect(() => { localStorage.setItem('solid_studio_paper_mode', String(paperMode)); }, [paperMode]);
  useEffect(() => { localStorage.setItem('solid_studio_is_vertical', String(isVertical)); }, [isVertical]);
  useEffect(() => { localStorage.setItem('solid_studio_is_sidebar_open', String(isSidebarOpen)); }, [isSidebarOpen]);
  useEffect(() => { localStorage.setItem('solid_studio_left_sidebar_width', String(leftSidebarWidth)); }, [leftSidebarWidth]);
  useEffect(() => { localStorage.setItem('solid_studio_right_sidebar_width', String(rightSidebarWidth)); }, [rightSidebarWidth]);

  useEffect(() => {
    if (isResizingLeft || isResizingRight) {
      document.body.style.userSelect = 'none';
      document.body.style.cursor = 'col-resize';
    } else {
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
    }
    return () => {
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
    };
  }, [isResizingLeft, isResizingRight]);

  const handleLeftResizeStart = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsResizingLeft(true);
    const startX = e.clientX;
    const startW = leftSidebarWidth;

    const handlePointerMove = (ev: PointerEvent) => {
      const delta = ev.clientX - startX;
      const maxW = Math.min(600, Math.floor(window.innerWidth * 0.45));
      const newW = Math.max(180, Math.min(maxW, startW + delta));
      setLeftSidebarWidth(newW);
    };

    const handlePointerUp = () => {
      setIsResizingLeft(false);
      document.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('pointerup', handlePointerUp);
      document.removeEventListener('pointercancel', handlePointerUp);
    };

    document.addEventListener('pointermove', handlePointerMove);
    document.addEventListener('pointerup', handlePointerUp);
    document.addEventListener('pointercancel', handlePointerUp);
  }, [leftSidebarWidth]);

  const handleRightResizeStart = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsResizingRight(true);
    const startX = e.clientX;
    const startW = rightSidebarWidth;

    const handlePointerMove = (ev: PointerEvent) => {
      const delta = startX - ev.clientX;
      const maxW = Math.min(600, Math.floor(window.innerWidth * 0.45));
      const newW = Math.max(200, Math.min(maxW, startW + delta));
      setRightSidebarWidth(newW);
    };

    const handlePointerUp = () => {
      setIsResizingRight(false);
      document.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('pointerup', handlePointerUp);
      document.removeEventListener('pointercancel', handlePointerUp);
    };

    document.addEventListener('pointermove', handlePointerMove);
    document.addEventListener('pointerup', handlePointerUp);
    document.addEventListener('pointercancel', handlePointerUp);
  }, [rightSidebarWidth]);
  useEffect(() => { 
    localStorage.setItem('solid_studio_language', language); 
    setSaveTxtStatus(language === 'EN' ? 'EXPORT (TXT)' : 'テキスト保存 (TXT)');
    setSaveJsonStatus(language === 'EN' ? 'ARCHIVE (JSON)' : '履歴保存 (JSON)');
  }, [language]);

  const loadHistory = (item: HistoryItem) => {
    setPrompt(item.keyword);
    setOutput(item.result);
    setActiveTab('SEARCH_BUFFER');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setAttachedImage(event.target?.result as string);
    };
    reader.readAsDataURL(file);
    e.target.value = ''; // Reset
  };

  const constructParts = (text: string, base64Image: string | null) => {
    const parts: any[] = [{ text: text || " " }];
    if (base64Image) {
      const mimeType = base64Image.split(';')[0].split(':')[1];
      const base64Data = base64Image.split(',')[1];
      parts.push({
        inlineData: {
          data: base64Data,
          mimeType: mimeType
        }
      });
    }
    return parts;
  };

  const handleExecute = async () => {
    if (!prompt.trim() && !attachedImage || isSearching) return;
    
    // Check API Key
    const currentKey = provider === 'GEMINI' ? (apiKey || process.env.GEMINI_API_KEY) : groqApiKey;
    if (!currentKey) {
      setOutput(`// FATAL_ERROR: API_KEY_MISSING\n// 右側のパネル「00 PROVIDER & KEY」から${provider}のAPIキーを設定してください。`);
      return;
    }
    
    setIsSearching(true);
    setOutput('');
    
    try {
      const systemInstruction = `# Role
次世代型検索OS「SOLID STUDIO AI SEARCH」のコア解析エンジン。
要求されたテーマに対し、圧倒的な情報密度、長文かつ徹底的な解説、そして美しく構造化されたMarkdownレイアウトで出力せよ。

# Parameters
- ENGINE_PRESET: ${engine} (QUICK: 要点まとめ, BALANCED: 充実した詳細解説, DEEP_RESEARCH: 徹底的かつ極めて多角的な長文深掘り)
- INFORMATION_DENSITY: ${density}/100 (${density > 50 ? "高密度・長文・詳細解説モード: 豊富な文字量で多面的に詳しく解説すること" : "標準モード"})
- OUTPUT_FORMAT: ${outputFormat}
- TARGET_LANGUAGE: ${language === 'EN' ? 'English' : '日本語'}
- PROVIDER: ${provider}

${outputFormat === 'RAW_JSON' ? `# Output Rule (RAW_JSON Mode)
純粋なJSONオブジェクトのみを出力せよ。コードブロックや説明文は含めないこと。
{
  "SUBJECT_SCAN": "タイトル",
  "SYSTEM_CORE": "ステータス",
  "01_CORE_DIRECTIVE": "核心結論",
  "02_DATA_GRID": [ { "項目": "内容" } ],
  "03_STRATEGIC_OVERVIEW": "詳細な戦略・背景分析長文",
  "04_SOURCE_NODES": [ "関連キーワード" ],
  "END_OF_TRANSMISSION": "タイムスタンプ"
}` : `# Layout & Formatting Directives (Strict Markdown)
必ず以下のMarkdown構文を厳格に使用して出力せよ。単なるプレーンテキストの羅列や挨拶、前置きは一切厳禁。

# [ SUBJECT_SCAN ] : 洗練された主題タイトル

> **[ SYSTEM CORE ]** ALL SYSTEMS GREEN.  
> EXECUTION: ${provider}_${engine} / DENSITY: ${density}% / TARGET: ${prompt || 'SEARCH_QUERY'}

## [ 01_CORE_DIRECTIVE ]
> 最も鋭く洗練されたワンフレーズの結論・核心命題

### [ 02_DATA_GRID ]
このセクションでは、具体的な事実・歴史・スペック・カテゴリ別データなどを、**必ずMarkdownの表（Table）を1つ以上作成して**視覚的かつ立体的に整理せよ。
さらに、表の前後に詳細な解説や要点を箇条書き（- **項目名**: 詳細説明）で豊富に記述し、高い情報量と文字ボリュームを担保すること。

| カテゴリ / 項目 | 詳細データ / 仕様 / 歴史 | 影響 / 意義 |
|---|---|---|
| (主要項目1) | (詳細な事実・データ) | (背景や影響) |
| (主要項目2) | (詳細な事実・データ) | (背景や影響) |
| (主要項目3) | (詳細な事実・データ) | (背景や影響) |

### [ 03_STRATEGIC_OVERVIEW ]
冷徹かつ多角的な視点からの本質的価値、歴史的・社会的背景、今後の課題や展望、戦略的分析。
単なる要約に留まらず、複数の段落にわたる重厚で知的な長文（しっかりとした文字量）で徹底的に深掘りして論述すること。

### [ 04_SOURCE_NODES ]
関連キーワードや概念ノードを以下のように列挙：
\`[ NODE: キーワード1 ]\` \`[ NODE: キーワード2 ]\` \`[ NODE: キーワード3 ]\` \`[ NODE: キーワード4 ]\`

---
// END_OF_TRANSMISSION : ${new Date().toLocaleTimeString('ja-JP')}`}

# Behavior & Tone
- トーン: 高度な知性、無機質かつスタイリッシュ、洗練された分析官の語り口。
- 文字量: 短縮せず、読者が納得できる充分なボリュームと多角的な視点を提供すること。`;
      const parts = constructParts(prompt, attachedImage);
      setAttachedImage(null); // use image and clear
      
      let text = '';

      if (provider === 'GEMINI') {
        const ai = new GoogleGenAI({ apiKey: currentKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.0-flash',
          contents: parts, // send parts array directly for single prompt
          config: {
            systemInstruction,
            tools: [{ googleSearch: {} }],
          }
        });
        text = response.text || '// ERROR: NO_RESPONSE_FROM_ENGINE';
      } else {
        const messages = [
          { role: 'system', content: systemInstruction },
        ];
        
        if (parts.length > 1) {
          messages.push({
            role: 'user',
            content: [
              { type: 'text', text: prompt || 'Analyze this image.' },
              { type: 'image_url', image_url: { url: `data:${(parts[1] as any).inlineData.mimeType};base64,${(parts[1] as any).inlineData.data}` } }
            ]
          } as any);
        } else {
          messages.push({ role: 'user', content: prompt } as any);
        }

        // List of candidate models supported by Groq (ordered by capability)
        const textCandidateModels = [
          'llama-3.3-70b-versatile',
          'openai/gpt-oss-120b',
          'qwen/qwen3.6-27b',
          'llama-3.1-8b-instant',
          'openai/gpt-oss-20b'
        ];
        const visionCandidateModels = [
          'qwen/qwen3.6-27b',
          'meta-llama/llama-4-scout-17b-16e-instruct',
          'llama-3.2-11b-vision-preview'
        ];

        const candidateModels = parts.length > 1 ? visionCandidateModels : textCandidateModels;
        
        let response: Response | null = null;
        let lastErrorMsg = '';

        for (const model of candidateModels) {
          const requestBody = JSON.stringify({
            model: model,
            messages: messages,
            max_tokens: density > 70 ? 8192 : density > 30 ? 4096 : 2048,
          });

          try {
            // First try direct API (standard for PWA / GitHub Pages hosting)
            response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentKey.trim()}`
              },
              body: requestBody
            });
          } catch {
            response = null;
          }

          // Fallback to local Vite dev proxy if direct fetch failed (e.g. running inside local Vite dev server)
          if (!response || !response.ok) {
            try {
              const proxyRes = await fetch('/api/groq/chat/completions', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${currentKey.trim()}`
                },
                body: requestBody
              });
              if (proxyRes.ok) {
                response = proxyRes;
              }
            } catch {}
          }

          if (response.ok) {
            break; // Success!
          }

          const errData = await response.json().catch(() => ({}));
          lastErrorMsg = errData.error?.message || response.statusText || `HTTP ${response.status}`;

          // If model doesn't exist or is deprecated, try next candidate
          if (lastErrorMsg.includes('does not exist') || lastErrorMsg.includes('deprecated') || lastErrorMsg.includes('model_not_found')) {
            continue;
          }
          // If it's another error (like auth or quota), break and report immediately
          break;
        }

        if (!response || !response.ok) {
          throw new Error(`Groq API: ${lastErrorMsg || 'リクエストに失敗しました'}`);
        }

        const data = await response.json();
        let rawContent = data.choices?.[0]?.message?.content || '// ERROR: NO_RESPONSE_FROM_ENGINE';
        text = rawContent.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
      }
      
      setOutput(text);
      
      const newHistory: HistoryItem = {
        id: Date.now().toString(),
        keyword: prompt || 'IMAGE_SEARCH',
        timestamp: new Date().toLocaleTimeString('ja-JP'),
        result: text
      };
      setHistory(prev => [newHistory, ...prev].slice(0, 10));
      
    } catch (error: any) {
      console.error(error);
      let errMsg = `// ERROR: ENGINE_EXECUTION_FAILURE\n// 詳細: ${error?.message || '通信に失敗しました'}`;
      if (error?.status === 429 || error?.message?.includes('429') || error?.message?.includes('quota') || error?.message?.includes('Rate limit')) {
        errMsg = `// FATAL_ERROR: QUOTA_EXCEEDED\n// 利用制限に達しました。しばらく待ってから再度お試しください。\n// ${error?.message || ''}`;
      } else if (error?.message?.includes('Invalid API Key') || error?.message?.includes('invalid_api_key')) {
        errMsg = `// ERROR: INVALID_API_KEY\n// 入力されたGroq APIキーが無効です。右側「00 プロバイダ & APIキー」でキー（gsk_...）を再確認してください。\n// ${error?.message || ''}`;
      }
      setOutput(errMsg);
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleExecute();
    }
  };

  const handleCopy = () => {
    const textToCopy = output;
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopyStatus('COPIED!');
    setTimeout(() => setCopyStatus(language === 'EN' ? 'COPY' : '結果をコピー (COPY)'), 2000);
  };

  const [saveTxtStatus, setSaveTxtStatus] = useState(language === 'EN' ? 'EXPORT (TXT)' : 'テキスト保存 (TXT)');
  const [saveJsonStatus, setSaveJsonStatus] = useState(language === 'EN' ? 'ARCHIVE (JSON)' : '履歴保存 (JSON)');
  const [driveDirName, setDriveDirName] = useState(language === 'EN' ? 'Not Set' : '未設定');
  const isIframe = window.self !== window.top;

  // Load handle name on mount
  useEffect(() => {
    if (isIframe) {
      setDriveDirName(language === 'EN' ? 'Browser DL Folder (iframe limit)' : 'ブラウザのDLフォルダ (iframe制限)');
      return;
    }
    gaiIdbGet(GAI_CLOUD_DIR_KEY).then(handle => {
      if (handle) setDriveDirName(handle.name);
    }).catch(() => {});
  }, [isIframe]);

  // 共通ファイル保存処理（ドライブ保存 または ブラウザダウンロード）
  const saveToFile = async (contentStr: string, filename: string, mimeType: string, onDone: () => void) => {
    const fallbackDownload = () => {
      const blob = new Blob([contentStr], { type: `${mimeType};charset=utf-8` });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
      onDone();
    };

    if (isIframe) {
      fallbackDownload();
      return;
    }

    try {
      let handle = await gaiIdbGet(GAI_CLOUD_DIR_KEY) as any;
      if (!handle) {
        if (!("showDirectoryPicker" in window)) {
          fallbackDownload();
          return;
        }
        handle = await (window as any).showDirectoryPicker({ mode: "readwrite" });
        await gaiIdbPut(GAI_CLOUD_DIR_KEY, handle);
        setDriveDirName(handle.name);
      }

      let perm = await handle.queryPermission({ mode: "readwrite" });
      if (perm !== "granted") {
        perm = await handle.requestPermission({ mode: "readwrite" });
      }

      if (perm !== "granted") {
        alert(language === "EN" ? "Folder access was not granted. Resetting configuration." : "フォルダへのアクセスが許可されませんでした。設定をリセットします。");
        await gaiIdbPut(GAI_CLOUD_DIR_KEY, null);
        setDriveDirName(language === "EN" ? "Not Set" : "未設定");
        fallbackDownload();
        return;
      }

      const fileHandle = await handle.getFileHandle(filename, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(contentStr);
      await writable.close();
      onDone();
    } catch (err: any) {
      console.error(err);
      if (err.name !== "AbortError") {
        fallbackDownload();
      }
    }
  };

  // 1. 通常のテキスト保存（.txt）
  const handleExportTxt = async () => {
    if (!output) return;
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const datePrefix = `${year}${month}${day}_${hours}${minutes}`;

    let title = prompt ? prompt.trim().substring(0, 30) : "SEARCH";
    const firstLine = output.split("\n")[0];
    if (firstLine.includes("[ SUBJECT_SCAN ] : ")) {
      const extractedTitle = firstLine.split("[ SUBJECT_SCAN ] : ")[1].trim();
      if (extractedTitle) title = extractedTitle.substring(0, 50);
    }
    title = title.replace(/[\\/:*?"<>|]/g, "_");
    const filename = `${datePrefix}_${title}.txt`;

    await saveToFile(output, filename, "text/plain", () => {
      setSaveTxtStatus("SAVED (TXT)!");
      setTimeout(() => setSaveTxtStatus(language === "EN" ? "EXPORT (TXT)" : "テキスト保存 (TXT)"), 2000);
    });
  };

  // 2. 履歴も含めたJSONアーカイブ保存（.json）
  const handleExportJson = async () => {
    if (!output && history.length === 0) return;
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const datePrefix = `${year}${month}${day}_${hours}${minutes}`;

    let title = prompt ? prompt.trim().substring(0, 30) : (history[0]?.keyword || "SEARCH_ARCHIVE");
    if (output) {
      const firstLine = output.split("\n")[0];
      if (firstLine.includes("[ SUBJECT_SCAN ] : ")) {
        const extractedTitle = firstLine.split("[ SUBJECT_SCAN ] : ")[1].trim();
        if (extractedTitle) title = extractedTitle.substring(0, 50);
      }
    }
    title = title.replace(/[\\/:*?"<>|]/g, "_");
    const filename = `${datePrefix}_${title}_archive.json`;

    const archiveData = {
      version: "5.4",
      app: "SOLID_STUDIO_AI_SEARCH",
      exportedAt: now.toISOString(),
      activeTab: activeTab,
      output: output,
      history: history
    };

    const jsonContent = JSON.stringify(archiveData, null, 2);

    await saveToFile(jsonContent, filename, "application/json", () => {
      setSaveJsonStatus("SAVED (JSON)!");
      setTimeout(() => setSaveJsonStatus(language === "EN" ? "ARCHIVE (JSON)" : "履歴保存 (JSON)"), 2000);
    });
  };

  const handleResetDrive = async () => {
    await gaiIdbPut(GAI_CLOUD_DIR_KEY, null);
    setDriveDirName(language === "EN" ? "Not Set" : "未設定");
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const raw = event.target?.result as string;
        try {
          const data = JSON.parse(raw);
          if (data.output !== undefined) setOutput(data.output);
          if (Array.isArray(data.history)) {
            setHistory(data.history);
            // outputが空でも最新のhistoryがあれば復元
            if (!data.output && data.history.length > 0) {
              setOutput(data.history[0].result);
              setPrompt(data.history[0].keyword);
            }
          }
          if (data.activeTab) setActiveTab(data.activeTab);
        } catch {
          // テキストファイル（.txt）がインポートされた場合の互換性
          setOutput(raw);
          setActiveTab("SEARCH_BUFFER");
        }
        setImportStatus("IMPORTED!");
        setTimeout(() => setImportStatus(language === "EN" ? "IMPORT" : "インポート (IMPORT)"), 2000);
      } catch (err) {
        setImportStatus("ERROR!");
        setTimeout(() => setImportStatus(language === "EN" ? "IMPORT" : "インポート (IMPORT)"), 2000);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  return (
    <div className="flex flex-col h-screen text-[11px] sm:text-xs tracking-widest uppercase selection:bg-[var(--border-color-highlight)] overflow-hidden">
      
      {/* HEADER */}
      <header className="h-14 border-b border-[var(--border-color)] bg-[var(--bg-color-panel)] flex items-center justify-between pl-8 sm:pl-12 pr-6 sm:pr-8 shrink-0 transition-colors duration-300 relative z-20">
        <div className="flex items-center gap-4 sm:gap-8 w-full">
          <div className={`flex items-center gap-2 font-extrabold text-xs sm:text-sm tracking-[0.2em] shrink-0 ${theme === 'LIGHT' ? 'text-black' : theme === 'PAPER' ? 'text-[var(--text-color-highlight)]' : 'text-white'}`}>
            <span className={theme === 'LIGHT' ? 'text-black/50' : theme === 'PAPER' ? 'text-[var(--accent-color)]' : 'text-white/50'}>{'>_'}</span> SOLID STUDIO AI SEARCH
            <span className="text-[9px] font-mono tracking-normal px-1.5 py-0.5 rounded bg-[var(--border-color)] text-[var(--accent-color)] border border-[var(--border-color-highlight)] font-semibold">v5.4</span>
          </div>
          
          <div className="flex items-center gap-2 ml-auto flex-1 max-w-2xl relative">
            <div className="flex items-center bg-[var(--bg-color-card)] border border-[var(--border-color)] rounded-sm px-3 py-1.5 w-full text-[var(--text-color-dim)] focus-within:border-[var(--text-color-dim)] transition-colors relative z-30">
              <Zap size={12} className="mr-2 text-[var(--accent-color)] shrink-0" />
              <input 
                type="text" 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={language === 'EN' ? "Enter search keyword / question..." : "検索キーワード / 質問を入力..."}
                className="bg-transparent outline-none w-full text-[var(--text-color-highlight)] placeholder:text-[var(--text-color-dim)] text-xs sm:text-sm font-sans normal-case"
                disabled={isSearching}
              />
            </div>
            
            {attachedImage && (
              <div className="absolute -bottom-10 left-4 p-1 bg-[var(--bg-color-card)] border border-[var(--border-color-highlight)] rounded-sm shadow-lg flex items-center gap-2 z-50">
                <img src={attachedImage} alt="attached" className="h-6 w-6 object-cover rounded-sm opacity-80" />
                <span className="text-[8px] text-[var(--text-color-highlight)] bg-[var(--bg-color-panel)] px-1 rounded">IMG_LOADED</span>
                <button onClick={() => setAttachedImage(null)} className="text-[var(--text-color-dim)] hover:text-red-400 p-0.5 bg-[var(--bg-color-base)] rounded-sm"><X size={10} /></button>
              </div>
            )}

            <button 
              onClick={handleExecute}
              disabled={isSearching}
              className="bg-[var(--bg-color-card)] border border-[var(--border-color-highlight)] hover:bg-[var(--border-color)] text-[var(--text-color-highlight)] hover:text-[var(--active-text-color,var(--text-color-highlight))] px-4 py-1.5 transition-colors disabled:opacity-50 shrink-0 font-bold rounded-sm shadow-sm"
            >
              {language === 'EN' ? 'RUN' : '実行'}
            </button>
            <button 
              onClick={() => imageInputRef.current?.click()}
              className="hidden sm:flex items-center gap-2 bg-[var(--bg-color-card)] border border-[var(--border-color)] hover:bg-[var(--border-color-highlight)] text-[var(--text-color-base)] px-4 py-1.5 transition-colors shrink-0 rounded-sm"
            >
              <Upload size={12} /> {language === 'EN' ? 'IMAGE' : '画像読込'}
            </button>
            <input type="file" ref={imageInputRef} accept="image/*" className="hidden" onChange={handleImageUpload} />

            <div className="hidden sm:flex border border-[var(--border-color)] bg-[var(--bg-color-card)] p-0.5 rounded-sm h-[30px] text-[10px] font-bold ml-2 shrink-0">
              <button 
                onClick={() => setLanguage('EN')}
                className={`px-3 h-full rounded-sm flex items-center justify-center transition-colors ${language === 'EN' ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))]' : 'text-[var(--text-color-dim)] hover:text-[var(--text-color-highlight)]'}`}
              >
                EN
              </button>
              <button 
                onClick={() => setLanguage('JP')}
                className={`px-3 h-full rounded-sm flex items-center justify-center transition-colors ${language === 'JP' ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))]' : 'text-[var(--text-color-dim)] hover:text-[var(--text-color-highlight)]'}`}
              >
                JP
              </button>
            </div>

            <button 
              onClick={toggleFullscreen}
              className="hidden sm:flex items-center justify-center border border-[var(--border-color)] bg-[var(--bg-color-card)] hover:bg-[var(--border-color)] text-[var(--text-color-dim)] hover:text-[var(--text-color-highlight)] w-[30px] h-[30px] rounded-sm transition-colors ml-1 shrink-0"
              title={language === 'EN' ? 'FULLSCREEN' : '全画面 (FULLSCREEN)'}
            >
              {isFullscreen ? <Shrink size={14} /> : <Expand size={14} />}
            </button>
          </div>
        </div>

        <div className="hidden md:flex flex-col items-end gap-1 text-[var(--text-color-base)] font-bold shrink-0 ml-4 w-32">
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${isSearching ? 'bg-yellow-500 animate-pulse' : 'bg-[var(--accent-color)] animate-pulse'}`}></div>
            <span className={isSearching ? 'text-yellow-500' : 'text-[var(--accent-color)]'}>
              {isSearching ? (language === 'EN' ? 'PROCESSING...' : '処理中...') : 'STABLE'}
            </span>
          </div>
          <div className="text-[8px] text-[var(--text-color-dim)]">VER_5.4.0_{language}</div>
        </div>
      </header>

      {/* MAIN CONTENT DIVIDER */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* LEFT PANEL */}
        <aside 
          style={{ width: isSidebarOpen ? `${leftSidebarWidth}px` : '0px' }}
          className={`${isSidebarOpen ? 'md:border-r-0 border-r' : 'overflow-hidden border-none'} border-[var(--border-color)] bg-[var(--bg-color-panel)] flex flex-col shrink-0 ${
            isResizingLeft ? '' : 'transition-[width] duration-150'
          } md:relative absolute z-10 h-full`}
        >
          <div className="p-3 flex-1 overflow-y-auto w-full custom-scrollbar">
            
            <div className="mb-4 border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm transition-colors duration-300">
              <div className="mb-2">
                <div className="flex justify-between text-[var(--text-color-dim)] font-bold mb-2 text-[11px]">
                  <span>{language === 'EN' ? '01 DENSITY' : '01 密度 (DENSITY)'}</span>
                  <span className="text-[var(--text-color-highlight)]">{density}</span>
                </div>
                <input 
                  type="range" 
                  value={density}
                  onChange={(e) => setDensity(Number(e.target.value))}
                  min={1} 
                  max={100} 
                  className="w-full industrial-slider" 
                />
              </div>
            </div>

            <div className="border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm mb-4 transition-colors duration-300">
              <div className="text-[var(--text-color-dim)] font-bold mb-2 text-[11px]">{language === 'EN' ? '02 ENGINE' : '02 エンジン (ENGINE)'}</div>
              <div className="flex flex-col gap-1">
                {(['BALANCED', 'DEEP_RESEARCH', 'QUICK'] as EngineType[]).map((e) => (
                  <button 
                    key={e}
                    onClick={() => setEngine(e)}
                    className={`py-1 px-2 text-left font-bold border transition-colors rounded-sm text-[11px] ${
                      engine === e 
                        ? 'bg-[var(--active-btn-bg,var(--border-color))] border-[var(--border-color-highlight)] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' 
                        : 'bg-[var(--bg-color-card)] border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-base))]'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>

            <div className="border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm mb-4 transition-colors duration-300">
              <div className="text-[var(--text-color-dim)] font-bold mb-2 text-[11px]">{language === 'EN' ? '03 FORMAT' : '03 形式 (FORMAT)'}</div>
              <div className="flex flex-col gap-1">
                {(['STANDARD', 'RAW_JSON', 'MINIMAL'] as OutputFormat[]).map((f) => (
                  <button 
                    key={f}
                    onClick={() => setOutputFormat(f)}
                    className={`py-1 px-2 text-left font-bold border transition-colors rounded-sm text-[11px] ${
                      outputFormat === f 
                        ? 'bg-[var(--active-btn-bg,var(--border-color))] border-[var(--border-color-highlight)] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' 
                        : 'bg-[var(--bg-color-card)] border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-base))]'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {/* TTS PANEL - full controls in sidebar */}
            <div className="border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm mt-4 transition-colors duration-300">
              <div className="text-[var(--text-color-dim)] font-bold mb-3 text-[11px] flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full shrink-0 transition-all ${ ttsIsPlaying ? 'bg-[var(--accent-color)] animate-pulse' : 'bg-[var(--border-color-highlight)]'}`}></span>
                <span>{language === 'EN' ? '09 VOICE (TTS)' : '09 音声 (TTS)'}</span>
              </div>

              {/* Play / Stop */}
              <div className="flex gap-1.5 mb-3">
                <button onClick={ttsPlayFromTop} disabled={!output || ttsIsPlaying} title={language === "EN" ? "Read from top" : "先頭から読み上げ"}
                  className="flex-1 py-1 px-1 text-center font-bold border transition-colors rounded-sm text-[11px] bg-transparent border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-highlight))] disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-1">
                  <span>▶</span><span>{language === 'EN' ? 'PLAY' : '再生'}</span>
                </button>
                <button onClick={ttsStop} disabled={!ttsIsPlaying} title={language === "EN" ? "Stop" : "停止"}
                  className="flex-1 py-1 px-1 text-center font-bold border transition-colors rounded-sm text-[11px] bg-transparent border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-highlight))] disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-1">
                  <span>⏹</span><span>{language === 'EN' ? 'STOP' : '停止'}</span>
                </button>
              </div>

              {/* Speed */}
              <div className="mb-2">
                <div className="flex justify-between text-[var(--text-color-dim)] font-bold mb-1 text-[11px]">
                  <span>{language === 'EN' ? 'SPEED' : '速度 (SPEED)'}</span>
                  <span className="text-[var(--text-color-highlight)]">{ttsRate.toFixed(1)}x</span>
                </div>
                <input type="range" value={ttsRate} onChange={(e) => setTtsRate(Number(e.target.value))}
                  min={0.5} max={4.0} step={0.1}
                  className="w-full industrial-slider" />
              </div>

              {/* Volume */}
              <div className="mb-2">
                <div className="flex justify-between text-[var(--text-color-dim)] font-bold mb-1 text-[11px]">
                  <span>{language === 'EN' ? 'VOLUME' : '音量 (VOL)'}</span>
                  <span className="text-[var(--text-color-highlight)]">{Math.round(ttsVolume * 100)}%</span>
                </div>
                <input type="range" value={ttsVolume} onChange={(e) => setTtsVolume(Number(e.target.value))}
                  min={0.0} max={1.0} step={0.05}
                  className="w-full industrial-slider" />
              </div>

              {/* Pitch */}
              <div className="mb-2">
                <div className="flex justify-between text-[var(--text-color-dim)] font-bold mb-1 text-[11px]">
                  <span>{language === 'EN' ? 'PITCH' : '音程 (PITCH)'}</span>
                  <span className="text-[var(--text-color-highlight)]">{ttsPitch.toFixed(1)}</span>
                </div>
                <input type="range" value={ttsPitch} onChange={(e) => setTtsPitch(Number(e.target.value))}
                  min={0.5} max={2.0} step={0.1}
                  className="w-full industrial-slider" />
              </div>

              {/* Voice */}
              <div>
                <div className="text-[var(--text-color-dim)] font-bold mb-1 text-[11px]">{language === 'EN' ? 'VOICE' : 'ボイス (VOICE)'}</div>
                <select value={ttsVoiceURI} onChange={(e) => setTtsVoiceURI(e.target.value)}
                  className="w-full bg-[var(--bg-color-base)] border border-[var(--border-color)] rounded-sm px-1.5 py-1 text-[var(--text-color-highlight)] text-[11px] outline-none focus:border-[var(--text-color-dim)] normal-case tracking-normal cursor-pointer">
                  {ttsVoices.map(v => (
                    <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>
                  ))}
                </select>
              </div>

              {output && (
                <div className="mt-2 text-[8px] text-[var(--text-color-dim)] text-center leading-tight">
                  {language === 'EN' ? 'Click paragraph to play' : '※段落をクリックで'}
                  <br/>{language === 'EN' ? '' : 'その箇所から読み上げ'}
                </div>
              )}
            </div>

          </div>
        </aside>

        {/* LEFT RESIZE HANDLE (INDUSTRIAL KNURL / DUAL-LINE GRIP) */}
        {isSidebarOpen && (
          <div
            onPointerDown={handleLeftResizeStart}
            onDoubleClick={() => setLeftSidebarWidth(260)}
            title={language === 'EN' ? 'Drag to resize sidebar (Double click to reset)' : 'ドラッグで幅調整（ダブルクリックでリセット）'}
            className={`hidden md:flex w-2 shrink-0 cursor-col-resize select-none relative z-20 flex-col justify-center items-center bg-[var(--bg-color-panel)] border-r border-[var(--border-color)] hover:bg-[var(--border-color-highlight)]/40 hover:border-[var(--border-color-highlight)] transition-colors group ${
              isResizingLeft ? '!bg-[var(--border-color-highlight)]/60 !border-[var(--accent-color)]' : ''
            }`}
          >
            {/* Industrial knurl / grip notches */}
            <div className="flex flex-col gap-1 items-center pointer-events-none py-4">
              <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingLeft ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
              <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingLeft ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
              <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingLeft ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
            </div>
          </div>
        )}

        {/* CENTER VIEWPORT */}
        <main className="flex-1 flex flex-col min-w-0 bg-transparent relative z-0 h-full">
           {/* TABS */}
           <div className="h-10 border-b border-[var(--border-color)] flex items-stretch justify-between px-2 sm:px-4 shrink-0 bg-[var(--bg-color-panel)] transition-colors duration-300 overflow-x-auto relative z-10">
              <div className="flex items-center gap-1 sm:gap-4 font-bold shrink-0 h-full">
                 <button 
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                    className="p-1.5 text-[var(--text-color-dim)] hover:text-[var(--text-color-highlight)] transition-colors rounded bg-[var(--bg-color-base)] border border-[var(--border-color)] mr-2 md:hidden h-7 flex items-center justify-center"
                 >
                    {isSidebarOpen ? <Shrink size={14} /> : <Expand size={14} />}
                 </button>
                 <button 
                    onClick={() => setActiveTab('SEARCH_BUFFER')}
                    className={`flex items-center justify-center gap-2 h-full border-b-2 px-2 sm:px-4 transition-colors ${activeTab === 'SEARCH_BUFFER' ? 'border-[var(--text-color-highlight)] text-[var(--text-color-highlight)] bg-[var(--bg-color-card)]' : 'border-transparent text-[var(--text-color-dim)] hover:text-[var(--text-color-base)]'}`}
                  >
                    <TerminalSquare size={14} /> <span className="mt-1">{language === 'EN' ? 'SEARCH BUFFER' : '検索バッファ'} <span className="hidden sm:inline">{language === 'EN' ? '' : 'その箇所から読み上げ'}</span></span>
                 </button>
                 <button 
                    onClick={() => { setEditContent(output); setActiveTab('EDIT_BUFFER'); }}
                    className={`flex items-center justify-center gap-2 h-full border-b-2 px-2 sm:px-4 transition-colors ${activeTab === 'EDIT_BUFFER' ? 'border-[var(--text-color-highlight)] text-[var(--text-color-highlight)] bg-[var(--bg-color-card)]' : 'border-transparent text-[var(--text-color-dim)] hover:text-[var(--text-color-base)]'}`}
                  >
                    <MessageSquare size={14} /> <span className="mt-1">{language === 'EN' ? 'EDIT CONTENT' : '検索内容の編集'} <span className="hidden sm:inline">{language === 'EN' ? '' : 'その箇所から読み上げ'}</span></span>
                 </button>
              </div>

              {/* TEXT FORMATTING TOOLBAR */}
              <div className="flex items-center gap-3 shrink-0 h-full text-[var(--text-color-dim)] pr-2 hidden md:flex">
                 
                 {/* Display Modes */}
                 <div className="flex items-center gap-1 border border-[var(--border-color)] bg-[var(--bg-color-card)] p-0.5 rounded-sm text-[11px] font-bold">
                    <button onClick={() => setPaperMode(!paperMode)} className={`px-2 py-1 rounded-sm transition-colors ${paperMode ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Toggle Paper Mode" : "ペーパーモード切替"}>
                       PAPER
                    </button>
                    <div className="w-px h-3 bg-[var(--border-color)] mx-1"></div>
                    <button onClick={() => setIsVertical(false)} className={`px-2 py-1 rounded-sm transition-colors ${!isVertical ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Horizontal" : "横組"}>
                       {language === 'EN' ? 'HORZ' : '横組'}
                    </button>
                    <button onClick={() => setIsVertical(true)} className={`px-2 py-1 rounded-sm transition-colors ${isVertical ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Vertical" : "縦組"}>
                       {language === 'EN' ? 'VERT' : '縦組'}
                    </button>
                 </div>

                 {/* Text Align */}
                 <div className="flex items-center gap-1 border border-[var(--border-color)] bg-[var(--bg-color-card)] p-0.5 rounded-sm">
                    <button onClick={() => setTextAlign('left')} className={`p-1 rounded-sm transition-colors ${textAlign === 'left' ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Align Left" : "左揃え"}>
                       <AlignLeft size={12} />
                    </button>
                    <button onClick={() => setTextAlign('center')} className={`p-1 rounded-sm transition-colors ${textAlign === 'center' ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Align Center" : "中央揃え"}>
                       <AlignCenter size={12} />
                    </button>
                    <button onClick={() => setTextAlign('right')} className={`p-1 rounded-sm transition-colors ${textAlign === 'right' ? 'bg-[var(--active-btn-bg,var(--border-color))] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' : 'hover:bg-[var(--bg-color-panel)]'}`} title={language === "EN" ? "Align Right" : "右揃え"}>
                       <AlignRight size={12} />
                    </button>
                 </div>

                 {/* Line Height */}
                 <div className="flex items-center gap-1.5 border border-[var(--border-color)] bg-[var(--bg-color-card)] px-2 py-0.5 rounded-sm" title={language === "EN" ? "Line Height" : "行間"}>
                    <ArrowDownUp size={12} className="shrink-0" />
                    <input 
                      type="range" 
                      value={lineHeight}
                      onChange={(e) => setLineHeight(Number(e.target.value))}
                      min={1.0} 
                      max={2.5}
                      step={0.1} 
                      className="w-16 industrial-slider" 
                    />
                 </div>

                 {/* Font Size */}
                 <div className="flex items-center gap-1.5 border border-[var(--border-color)] bg-[var(--bg-color-card)] px-2 py-0.5 rounded-sm" title={language === 'EN' ? 'Font Size' : '文字サイズ'}>
                    <Type size={12} className="shrink-0" />
                    <input 
                      type="range" 
                      value={fontSizeRem}
                      onChange={(e) => setFontSizeRem(Number(e.target.value))}
                      min={0.6} 
                      max={2.0}
                      step={0.05} 
                      className="w-16 industrial-slider" 
                    />
                 </div>
              </div>
           </div>

           {/* CANVAS */}
           <div className="flex-1 relative bg-dots overflow-hidden w-full h-full">
              
              {/* SEARCH BUFFER VIEW */}
              <div 
                ref={searchViewRef}
                className={`absolute inset-0 overflow-y-auto transition-opacity duration-300 ${activeTab === 'SEARCH_BUFFER' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none z-0'}`}
              >
                  {!output && !isSearching && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-[var(--border-color-highlight)] p-4 text-center">
                       <TerminalSquare size={48} className="mb-4 opacity-50" />
                       <span className="font-bold tracking-[0.3em] italic">{language === 'EN' ? 'Please run a search' : '検索を実行してください'}<br/><span className="text-[8px] opacity-70">AWAITING_INPUT</span></span>
                    </div>
                  )}

                  {isSearching && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-[var(--accent-color)] bg-[var(--bg-color-base)]/80 backdrop-blur-sm z-10">
                       <Loader2 size={48} className="mb-4 animate-spin opacity-80" />
                       <span className="font-bold tracking-[0.3em] animate-pulse">{language === 'EN' ? 'Analyzing information...' : '情報を解析中...'}<br/><span className="text-[8px] opacity-70">QUERYING_GLOBAL_NETWORK</span></span>
                    </div>
                  )}

                  {output && !isSearching && (
                    <div className={`p-4 sm:p-8 w-full max-w-none mx-auto ${isVertical ? 'h-[calc(100vh-140px)]' : 'min-h-full pb-20'}`}>
                      <div 
                        ref={setScrollContainerRef}
                        className={`border border-[var(--border-color)] bg-[var(--bg-color-card)] p-6 sm:p-10 shadow-2xl rounded-sm transition-colors duration-300 w-full overflow-auto ${paperMode ? 'paper-mode' : ''}`}
                        style={{
                           height: isVertical ? '100%' : 'auto',
                        }}
                        dir={isVertical ? 'rtl' : 'ltr'}
                      >
                        <div
                          className={`markdown-body break-words normal-case ${isVertical ? 'h-full min-w-full' : ''}`}
                          style={{ 
                            fontSize: `${fontSizeRem}rem`,
                            lineHeight: lineHeight,
                            textAlign: textAlign,
                            writingMode: isVertical ? 'vertical-rl' : 'horizontal-tb',
                          }}
                          dir="ltr"
                          onClick={(e) => {
                            // Toggle: if playing → stop; if stopped → play from clicked paragraph
                            if (ttsIsPlaying) {
                              ttsStop();
                              return;
                            }
                            const target = e.target as HTMLElement;
                            const block = target.closest('p, h1, h2, h3, h4, li, blockquote, td') as HTMLElement | null;
                            if (block) {
                              const text = block.innerText;
                              if (text.trim()) ttsPlayFromParagraph(text.trim());
                            }
                          }}
                        >
                          <Markdown remarkPlugins={[remarkGfm]}>{output}</Markdown>
                        </div>
                      </div>
                    </div>
                  )}
              </div>

              {/* EDIT BUFFER VIEW */}
              <div className={`absolute inset-0 flex flex-col transition-opacity duration-300 z-10 bg-[var(--bg-color-card)] overflow-hidden ${activeTab === 'EDIT_BUFFER' ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                 <div className="flex flex-col h-full min-h-0">
                    <textarea 
                      ref={setEditScrollContainerRef}
                      className="flex-1 w-full min-h-0 bg-transparent p-4 sm:p-8 pb-4 font-mono text-[var(--text-color-highlight)] outline-none resize-none custom-scrollbar"
                      style={{ 
                        fontSize: `${fontSizeRem}rem`,
                        writingMode: isVertical ? 'vertical-rl' : 'horizontal-tb',
                        lineHeight: lineHeight,
                        textAlign: textAlign,
                      }}
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      placeholder="// NO_DATA_AVAILABLE"
                    />
                    <div className="p-4 sm:p-8 pt-4 shrink-0 bg-[var(--bg-color-card)] flex justify-end gap-2 sm:gap-4 border-t border-[var(--border-color)]">
                      <button 
                        onClick={() => { setEditContent(output); setActiveTab('SEARCH_BUFFER'); }}
                        className="text-[var(--text-color-dim)] hover:text-[var(--text-color-highlight)] transition-colors px-2 sm:px-4 py-2 font-bold text-[11px] sm:text-xs"
                      >
                        language === 'EN' ? 'CANCEL' : 'キャンセル (CANCEL)'
                      </button>
                      <button 
                        onClick={() => { setOutput(editContent); setActiveTab('SEARCH_BUFFER'); }}
                        className="bg-[var(--accent-color)] text-[#000000] px-4 sm:px-6 py-2 rounded-sm font-bold transition-all hover:brightness-110 text-[11px] sm:text-xs tracking-wider uppercase shadow-lg border border-transparent hover:border-[#ffffff55]"
                      >
                        language === 'EN' ? 'SAVE EDITS' : '編集内容の保存 (SAVE)'
                      </button>
                    </div>
                 </div>
              </div>

              {/* OVERLAY CONTROLS */}
              <div className={`absolute bottom-6 right-6 flex flex-col gap-2 z-20 transition-transform duration-300`}>
                 {activeTab === 'SEARCH_BUFFER' && output && (
                   <>
                     <button onClick={handleExportTxt} title={language === "EN" ? "Download Text" : "テキスト保存 (TXT)"} className="w-10 h-10 bg-[var(--bg-color-card)] border border-[var(--border-color)] rounded-sm flex items-center justify-center text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-highlight))] transition-colors shadow-lg">
                        <Download size={14} />
                     </button>
                     <button onClick={() => setOutput('')} title={language === "EN" ? "Clear Output" : "出力をクリア"} className="w-10 h-10 bg-[var(--bg-color-card)] border border-[var(--border-color)] rounded-sm flex items-center justify-center text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-highlight))] transition-colors shadow-lg">
                        <RotateCcw size={14} />
                     </button>
                   </>
                 )}
              </div>
           </div>
        </main>

        {/* RIGHT RESIZE HANDLE (INDUSTRIAL KNURL / DUAL-LINE GRIP) */}
        <div
          onPointerDown={handleRightResizeStart}
          onDoubleClick={() => setRightSidebarWidth(260)}
          title={language === 'EN' ? 'Drag to resize sidebar (Double click to reset)' : 'ドラッグで幅調整（ダブルクリックでリセット）'}
          className={`hidden lg:flex w-2 shrink-0 cursor-col-resize select-none relative z-20 flex-col justify-center items-center bg-[var(--bg-color-panel)] border-l border-[var(--border-color)] hover:bg-[var(--border-color-highlight)]/40 hover:border-[var(--border-color-highlight)] transition-colors group ${
            isResizingRight ? '!bg-[var(--border-color-highlight)]/60 !border-[var(--accent-color)]' : ''
          }`}
        >
          {/* Industrial knurl / grip notches */}
          <div className="flex flex-col gap-1 items-center pointer-events-none py-4">
            <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingRight ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
            <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingRight ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
            <div className={`w-[2px] h-2.5 rounded-[0.5px] transition-colors ${isResizingRight ? 'bg-[var(--accent-color)]' : 'bg-[var(--border-color-highlight)] group-hover:bg-[var(--accent-color)]'}`} />
          </div>
        </div>

        {/* RIGHT PANEL - hidden on small screens unless toggled, let's keep it visible on lg */}
        <aside 
          style={{ width: `${rightSidebarWidth}px` }}
          className={`bg-[var(--bg-color-panel)] shrink-0 hidden lg:flex flex-col z-20 ${
            isResizingRight ? '' : 'transition-colors duration-300'
          }`}
        >
          <div className="p-3 flex-1 overflow-y-auto custom-scrollbar w-full">
             <div className="mb-4 border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm transition-colors duration-300">
               <div className="flex items-center justify-between mb-2">
                 <div className="text-[var(--text-color-dim)] font-bold text-[11px]">{language === 'EN' ? '00 PROVIDER & KEY' : '00 プロバイダ & APIキー'}</div>
               </div>
               <div className="flex gap-1 mb-2">
                 {(['GEMINI', 'GROQ'] as Provider[]).map((p) => (
                   <button
                     key={p}
                     onClick={() => setProvider(p)}
                     className={`flex-1 py-1 text-center font-bold border transition-colors rounded-sm text-[10px] ${
                       provider === p
                         ? 'bg-[var(--active-btn-bg,var(--border-color))] border-[var(--border-color-highlight)] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm'
                         : 'bg-[var(--bg-color-card)] border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-base))]'
                     }`}
                   >
                     {p}
                   </button>
                 ))}
               </div>
               {provider === 'GEMINI' ? (
                 <input 
                   type="text"
                   value={apiKey}
                   onChange={(e) => setApiKey(e.target.value)}
                   placeholder="Gemini API Key (AIzaSy...)"
                   autoComplete="off"
                   spellCheck="false"
                   data-1p-ignore
                   style={{ WebkitTextSecurity: 'disc' } as any}
                   className="w-full bg-[var(--bg-color-base)] border border-[var(--border-color)] rounded-sm px-2 py-1 text-[var(--text-color-highlight)] text-[11px] outline-none focus:border-[var(--text-color-dim)]"
                 />
               ) : (
                 <input 
                   type="text"
                   value={groqApiKey}
                   onChange={(e) => setGroqApiKey(e.target.value)}
                   placeholder="Groq API Key (gsk_...)"
                   autoComplete="off"
                   spellCheck="false"
                   data-1p-ignore
                   style={{ WebkitTextSecurity: 'disc' } as any}
                   className="w-full bg-[var(--bg-color-base)] border border-[var(--border-color)] rounded-sm px-2 py-1 text-[var(--text-color-highlight)] text-[11px] outline-none focus:border-[var(--text-color-dim)]"
                 />
               )}
             </div>

             <div className="mb-4 border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm transition-colors duration-300">
               <div className="text-[var(--text-color-dim)] font-bold mb-3 text-[11px]">{language === 'EN' ? '06 THEMES' : '06 テーマ (THEMES)'}</div>
               <div className="grid grid-cols-2 gap-1.5">
                 {(['DARK', 'BLACK', 'MID', 'RED', 'LIGHT', 'PAPER'] as Theme[]).map((t) => (
                   <button 
                     key={t}
                     onClick={() => setTheme(t)}
                     className={`py-1 px-1 text-center font-bold border transition-colors rounded-sm text-[11px] ${
                       theme === t 
                         ? 'bg-[var(--active-btn-bg,var(--border-color))] border-[var(--border-color-highlight)] text-[var(--active-text-color,var(--text-color-highlight))] shadow-sm' 
                         : 'bg-[var(--bg-color-card)] border-[var(--border-color)] text-[var(--text-color-dim)] hover:bg-[var(--border-color)] hover:text-[var(--active-text-color,var(--text-color-base))]'
                     }`}
                   >
                     {t}
                   </button>
                 ))}
               </div>
             </div>

             <div className="border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm transition-colors duration-300 flex-1 flex flex-col h-1/2">
               <div className="text-[var(--text-color-dim)] font-bold mb-3 text-[11px] shrink-0">{language === 'EN' ? '07 HISTORY' : '07 履歴 (HISTORY)'}</div>
               <div className="flex flex-col gap-2 overflow-y-auto flex-1 pr-1">
                 {history.length === 0 ? (
                   <div className="py-8 text-center border border-dashed border-[var(--border-color)] text-[var(--text-color-dim)] text-[8px]">
                     EMPTY_RECORD
                   </div>
                 ) : (
                   history.map((item) => (
                     <div 
                       key={item.id}
                       className="border border-[var(--border-color)] bg-transparent hover:bg-[var(--border-color)] transition-colors group rounded-sm flex items-stretch"
                     >
                       <button
                         onClick={() => loadHistory(item)}
                         className="flex-1 p-3 text-left overflow-hidden"
                       >
                         <div className="text-[var(--accent-color)] mb-1 text-[8px]">{item.timestamp}</div>
                         <div className="text-[var(--text-color-base)] group-hover:text-[var(--text-color-highlight)] truncate text-xs normal-case font-sans">{item.keyword}</div>
                       </button>
                       <button
                         onClick={(e) => { e.stopPropagation(); setHistory(prev => prev.filter(h => h.id !== item.id)); }}
                         className="px-3 text-[var(--text-color-dim)] hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center border-l border-transparent group-hover:border-[var(--border-color)]"
                         title={language === 'EN' ? "Delete" : "削除"}
                       >
                         <X size={14} />
                       </button>
                     </div>
                   ))
                 )}
                 {history.length > 0 && (
                    <button onClick={() => setHistory([])} className="mt-2 text-xs text-[var(--text-color-dim)] hover:text-[var(--text-color-base)] p-2 border border-transparent hover:border-[var(--border-color)] rounded-sm transition-colors">language === 'EN' ? 'CLEAR HISTORY' : '履歴をクリア'</button>
                 )}
               </div>
             </div>
             
             <div className="mt-4 border border-[var(--border-color)] p-2.5 bg-[var(--bg-color-card)] rounded-sm transition-colors duration-300">
               <div className="text-[var(--text-color-dim)] font-bold mb-2 text-[11px] flex justify-between items-center">
                 <span>{language === 'EN' ? '08 DRIVE (SAVE LOCATION)' : '08 DRIVE 保存先'}</span>
                 {driveDirName !== '未設定' && (
                   <button onClick={handleResetDrive} className="text-[var(--accent-color)] hover:text-[#ff4444] hover:underline cursor-pointer">language === 'EN' ? 'CHANGE (CLEAR)' : '変更(CLEAR)'</button>
                 )}
               </div>
               <div className="text-[11px] text-[var(--text-color-base)] truncate bg-[var(--bg-color-base)] border border-[var(--border-color)] p-2 rounded-sm text-center">
                 {driveDirName}
               </div>
             </div>
          </div>
        </aside>

      </div>

      {/* FOOTER */}
      <footer className="h-10 border-t border-[var(--border-color)] bg-[var(--bg-color-panel)] flex items-stretch shrink-0 text-[var(--text-color-dim)] font-bold divide-x divide-[var(--border-color)] transition-colors duration-300 overflow-x-auto whitespace-nowrap relative z-20">
         <button onClick={handleCopy} className="px-6 flex-1 h-full hover:bg-[var(--bg-color-card)] hover:text-[var(--text-color-highlight)] transition-colors text-[11px] flex items-center justify-center"><span className="mt-1">{copyStatus === 'COPIED!' ? 'COPIED!' : (language === 'EN' ? 'COPY' : '結果をコピー (COPY)')}</span></button>
         <button onClick={() => setOutput('')} className="px-6 flex-1 h-full hover:bg-[var(--bg-color-card)] hover:text-[var(--text-color-highlight)] transition-colors text-[11px] flex items-center justify-center"><span className="mt-1">language === 'EN' ? 'CLEAR' : 'クリア (CLEAR)'</span></button>
         <button onClick={() => importFileRef.current?.click()} className="px-6 flex-1 h-full hover:bg-[var(--bg-color-card)] hover:text-[var(--text-color-highlight)] transition-colors text-[11px] flex items-center justify-center"><span className="mt-1">{importStatus === 'IMPORTED!' ? 'IMPORTED!' : importStatus === 'ERROR!' ? 'ERROR!' : (language === 'EN' ? 'IMPORT' : 'インポート (IMPORT)')}</span></button>
         <input type="file" ref={importFileRef} accept=".json,.txt" className="hidden" onChange={handleImport} />
         <button onClick={handleExportTxt} className="px-4 flex-1 h-full hover:bg-[var(--bg-color-card)] hover:text-[var(--text-color-highlight)] transition-colors text-[11px] flex items-center justify-center"><span className="mt-1">{saveTxtStatus}</span></button>
         <button onClick={handleExportJson} className="px-4 flex-1 h-full hover:bg-[var(--bg-color-card)] hover:text-[var(--text-color-highlight)] transition-colors text-[11px] flex items-center justify-center"><span className="mt-1">{saveJsonStatus}</span></button>
      </footer>
    </div>
  );
}
